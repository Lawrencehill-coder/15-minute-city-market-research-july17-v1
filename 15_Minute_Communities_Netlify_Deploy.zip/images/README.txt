All image slots are filled as of v7.0:
  seaside.jpg              - Origins section (Seaside, FL)
  carlos-moreno.jpg        - Who is Carlos Moreno section (his portrait)
  paris-street.jpg         - Who is Carlos Moreno section (aerial Paris)
  woodlands.jpg             - Texas market section (The Woodlands Waterway)
  mueller-market.jpg        - Mueller, Austin case study
  builders-model.jpg        - Largest builders section
  fields-construction.jpg   - Fields, Frisco case study
  mixed-use-street.jpg      - Mirada & Angeline case study
  dallas-siteplan.jpg       - Texas section (second image)
  community-life.jpg        - Gains section

Keep this images/ folder in the same directory as the HTML file.
If you ever swap a photo, keep the filename the same and just
replace the file -- refresh the browser and it updates.
